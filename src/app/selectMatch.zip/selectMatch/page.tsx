"use client";
import { useState, useEffect } from "react";

// Types for our match data
interface Match {
  id: string;
  tournamentId: string;
  teamOne: string;
  teamTwo: string;
  category: string;
  date: string;
}

// Sample match data (replace with your actual data fetching logic)
const sampleMatches: Match[] = [
  {
    id: "1",
    tournamentId: "101",
    teamOne: "Barcelona",
    teamTwo: "Real Madrid",
    category: "Football",
    date: "2025-05-20",
  },
  {
    id: "2",
    tournamentId: "101",
    teamOne: "Liverpool",
    teamTwo: "Manchester United",
    category: "Football",
    date: "2025-05-21",
  },
  {
    id: "3",
    tournamentId: "102",
    teamOne: "Lakers",
    teamTwo: "Warriors",
    category: "Basketball",
    date: "2025-05-22",
  },
  {
    id: "4",
    tournamentId: "103",
    teamOne: "Nadal",
    teamTwo: "Federer",
    category: "Tennis",
    date: "2025-05-23",
  },
];

// Modal component to display match details
const MatchDetailsModal = ({ match, isOpen, onClose, children }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Match Details</h2>
          <button
            onClick={onClose}
            className="bg-gray-200 rounded-full p-2 hover:bg-gray-300"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              ></path>
            </svg>
          </button>
        </div>

        {match ? (
          <div className="space-y-4">
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <div className="text-lg font-semibold">{match.teamOne}</div>
                <div className="text-sm bg-gray-200 px-2 py-1 rounded">VS</div>
                <div className="text-lg font-semibold">{match.teamTwo}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-gray-500 text-sm">Match ID</p>
                <p className="font-medium">{match.id}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-gray-500 text-sm">Tournament ID</p>
                <p className="font-medium">{match.tournamentId}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-gray-500 text-sm">Category</p>
                <p className="font-medium">{match.category}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded">
                <p className="text-gray-500 text-sm">Date</p>
                <p className="font-medium">
                  {new Date(match.date).toLocaleDateString()}
                </p>
              </div>
            </div>

            {/* Additional content passed as children */}
            {children && <div className="mt-4 border-t pt-4">{children}</div>}
          </div>
        ) : (
          <div className="text-center py-8">No match selected</div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default function MatchSelector() {
  // State for matches and selected match
  const [matches, setMatches] = useState<Match[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch matches (simulate API call)
  useEffect(() => {
    // In a real app, replace this with your API call
    setMatches(sampleMatches);
  }, []);

  // Handle match selection
  const handleMatchSelect = (e) => {
    const matchId = e.target.value;
    if (!matchId) {
      setSelectedMatch(null);
      return;
    }

    const match = matches.find((m) => m.id === matchId);
    if (match) {
      setSelectedMatch(match);
      setIsModalOpen(true);
    }
  };

  // Close modal function
  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <label
          htmlFor="match-select"
          className="block text-sm font-medium text-gray-700 mb-2"
        >
          Select a Match
        </label>
        <select
          id="match-select"
          value={selectedMatch?.id || ""}
          onChange={handleMatchSelect}
          className="w-full bg-white border border-gray-300 rounded-md py-2 px-3 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">-- Select a match --</option>
          {matches.map((match) => (
            <option key={match.id} value={match.id}>
              {match.teamOne} vs {match.teamTwo} - {match.category}
            </option>
          ))}
        </select>
      </div>

      {/* Display selected match info (optional) */}
      {selectedMatch && (
        <div className="mb-4 p-4 bg-blue-50 rounded-md">
          <p className="font-medium">
            Selected: {selectedMatch.teamOne} vs {selectedMatch.teamTwo}
          </p>
          <p className="text-sm text-gray-600">
            Match ID: {selectedMatch.id} | Tournament ID:{" "}
            {selectedMatch.tournamentId}
          </p>
        </div>
      )}

      {/* Modal with match details */}
      <MatchDetailsModal
        match={selectedMatch}
        isOpen={isModalOpen}
        onClose={closeModal}
      >
        {/* This is the child content that will only be shown when modal is open */}
        <div className="bg-yellow-50 p-4 rounded-lg">
          <h3 className="font-medium text-lg mb-2">
            Additional Match Information
          </h3>
          <p>
            This section can contain any additional information about the match
            that you want to display.
          </p>
          <p className="mt-2 text-sm text-gray-600">
            This content is passed as a child to the modal and only appears when
            the modal is open.
          </p>
        </div>
      </MatchDetailsModal>
    </div>
  );
}
